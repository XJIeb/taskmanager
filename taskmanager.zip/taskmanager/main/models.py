from django.db import models


class Task(models.Model):
    title = models.CharField('Шишка', max_length=50)
    task = models.TextField('Бошечка')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Дар'
        verbose_name_plural = 'Дары'

